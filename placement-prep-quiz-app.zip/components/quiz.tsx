"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { CheckCircle2, XCircle, BookOpen } from "lucide-react";

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
}

const QUESTIONS: Question[] = [
  {
    id: 1,
    question: "What is the time complexity of binary search?",
    options: ["O(n)", "O(log n)", "O(n^2)"],
    correctAnswer: "O(log n)",
  },
  {
    id: 2,
    question: "Which data structure uses LIFO principle?",
    options: ["Queue", "Stack", "Array"],
    correctAnswer: "Stack",
  },
  {
    id: 3,
    question: "What does SQL stand for?",
    options: [
      "Structured Query Language",
      "Simple Query Language",
      "Standard Query Logic",
    ],
    correctAnswer: "Structured Query Language",
  },
];

interface QuizResult {
  score: number;
  total: number;
}

export function Quiz() {
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [result, setResult] = useState<QuizResult | null>(null);

  const handleAnswerChange = (questionId: number, answer: string) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: answer,
    }));
  };

  const handleSubmit = () => {
    let score = 0;
    for (const question of QUESTIONS) {
      if (answers[question.id] === question.correctAnswer) {
        score++;
      }
    }
    setResult({ score, total: QUESTIONS.length });
  };

  const handleRetry = () => {
    setResult(null);
    setAnswers({});
  };

  const allQuestionsAnswered =
    QUESTIONS.length > 0 &&
    QUESTIONS.every((q) => answers[q.id] !== undefined);

  if (result) {
    const percentage = Math.round((result.score / result.total) * 100);
    const isPassing = percentage >= 60;

    return (
      <Card className="w-full max-w-2xl shadow-lg border-0">
        <CardHeader className="text-center pb-2">
          <div className="flex justify-center mb-4">
            {isPassing ? (
              <CheckCircle2 className="h-16 w-16 text-success" />
            ) : (
              <XCircle className="h-16 w-16 text-destructive" />
            )}
          </div>
          <CardTitle className="text-2xl">Quiz Complete!</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center gap-6 py-6">
          <div className="text-center">
            <p className="text-5xl font-bold text-foreground mb-2">
              Your Score: {result.score} / {result.total}
            </p>
            <p className="text-muted-foreground text-lg">{percentage}% correct</p>
          </div>
          <p
            className={`text-lg font-medium ${isPassing ? "text-success" : "text-muted-foreground"}`}
          >
            {isPassing
              ? "Great job! Keep it up!"
              : "Keep practicing, you'll get better!"}
          </p>
          <Button onClick={handleRetry} size="lg" className="mt-2">
            Take Quiz Again
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-2xl shadow-lg border-0">
      <CardHeader className="border-b border-border pb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <BookOpen className="h-6 w-6 text-primary" />
          </div>
          <div>
            <CardTitle className="text-xl">Placement Prep Quiz</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Answer all {QUESTIONS.length} questions below
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-8">
          {QUESTIONS.map((question, index) => (
            <div key={question.id} className="space-y-4">
              <div className="flex gap-3">
                <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-semibold">
                  {index + 1}
                </span>
                <p className="text-foreground font-medium leading-relaxed pt-1">
                  {question.question}
                </p>
              </div>
              <RadioGroup
                value={answers[question.id] || ""}
                onValueChange={(value) => handleAnswerChange(question.id, value)}
                className="ml-11 space-y-2"
              >
                {question.options.map((option, optionIndex) => (
                  <div
                    key={optionIndex}
                    className={`flex items-center space-x-3 rounded-lg border p-3 transition-colors cursor-pointer hover:bg-secondary/50 ${
                      answers[question.id] === option
                        ? "border-primary bg-primary/5"
                        : "border-border"
                    }`}
                  >
                    <RadioGroupItem
                      value={option}
                      id={`q${question.id}-option${optionIndex}`}
                      className="flex-shrink-0"
                    />
                    <Label
                      htmlFor={`q${question.id}-option${optionIndex}`}
                      className="flex-1 cursor-pointer text-foreground"
                    >
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-border">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">
              {Object.keys(answers).length} of {QUESTIONS.length} questions
              answered
            </p>
            <Button
              onClick={handleSubmit}
              disabled={!allQuestionsAnswered}
              size="lg"
              className="w-full sm:w-auto min-w-[140px]"
            >
              Submit Quiz
            </Button>
          </div>
          {!allQuestionsAnswered && QUESTIONS.length > 0 && (
            <p className="text-sm text-muted-foreground text-center sm:text-right mt-2">
              Please answer all questions to submit
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
